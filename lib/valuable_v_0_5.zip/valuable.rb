class Valuable

  def attributes
    @attributes ||= {} 
  end

  def initialize(atts = {})
    self.class.attributes.each do |att_name| 
      value = atts.has_key?(att_name) ? atts[att_name] : atts[att_name.to_s]
      send("#{att_name}=", value )
    end 
  end

  def deep_duplicate_of(value)
    Marshal.load(Marshal.dump(value))
  end

  def pick( value, default)
    if value == nil
      default
    else
      value
    end
  end
  
  class << self

    def attributes
      @attributes ||= []
    end 

    def formatter
      @formatter ||= {}
    end
    
    def has_value(name, options={})
      attributes << name 

      create_accessor_for(name)
      create_setter_for(name, options[:klass], options[:default])
    end

    def create_setter_for(name, klass, default)
        
      if klass == nil
        define_method "#{name}=" do |value|
          attributes[name] = pick( value, deep_duplicate_of(default) ) 
        end

      elsif klass == Integer

        define_method "#{name}=" do |value|
          value_as_integer = value && value.to_i
          attributes[name] = pick( value_as_integer, deep_duplicate_of(default))
        end

      elsif klass == String
	
	define_method "#{name}=" do |value|
          value_as_string = value && value.to_s
          attributes[name] = pick( value_as_string, deep_duplicate_of(default))
	end

      else

        define_method "#{name}=" do |value|
          if value.nil?
            attributes[name] = deep_duplicate_of(default)
	  elsif value.is_a? klass
	    attributes[name] = value
	  else
	    attributes[name] = klass.new(value)
	  end
        end
      end
    end

    def create_accessor_for(name)
      define_method name do
        attributes[name]
      end
    end

    def has_collection(name)
      has_value(name, :default => [] )
    end 

  end

end
